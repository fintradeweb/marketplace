@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <h5>Welcome</h5></br>      
      <div class="list-group">
        @foreach ($notifications as $notification)   
          <a href="/home" class="list-group-item list-group-item-action active">Not 1</a>
        @endforeach
      </div> 
    </div>
  </div>
</div>
@endsection
