
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
 <div class="row justify-content-center">
   <div class="col-md-8 col-lg-8 col-sm-12">
     <div class="alert alert-success">
      <?php echo e(session('status')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
     </div>
   </div>
 </div>    
<?php endif; ?>

<div class="container">
  <div class="row justify-content-center">  
    <div class="row col-md-12 p-4">
      <div class="col-md-6"><h5>Consult Credit User of - <?php echo e($business->company_name); ?></h5></div>
      <div class="col-md-6 ml-auto text-right">
        <a href="/users"class="btn btn-primary">Return</a>
      </div>
    </div> 
    <?php if($credit_status == 'Request received'): ?>
      <div class="row col-md-12 col-lg-12 col-sm-12 p-4">
        <div class="col-md-4 text-center">   
          <a href="/credit/<?php echo e($iduser); ?>/approve" data-toggle="tooltip" data-placement="top" title="Approve Credit">
            <i class="fa fa-check-square-o" aria-hidden="true" style="font-size:25px;"></i>&nbsp;Approve Credit
          </a>      
        </div>
        <div class="col-md-4 text-center">
          <a href="/credit/<?php echo e($iduser); ?>/deny" data-toggle="tooltip" data-placement="top" title="Deny Credit">
            <i class="fa fa-window-close" aria-hidden="true" style="font-size:25px;"></i>&nbsp;Deny Credit
          </a>  
        </div>  
        <div class="col-md-4 text-center">  
          <a href="/credit/<?php echo e($iduser); ?>/askmore/" data-toggle="tooltip" data-placement="top" title="Ask more information">
            <i class="fa fa-question" aria-hidden="true" style="font-size:25px;"></i>&nbsp;Ask more information
          </a>
        </div>
      </div>
    <?php endif; ?>
   
    <div class="row col-md-12 col-lg-12 col-sm-12">
      <ul class="nav nav-pills" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
          <a class="nav-link active" id="pills-business-tab" data-toggle="pill" href="#pills-business" role="tab" aria-controls="pills-business" aria-selected="true">Business Information</a>
        </li>
        <li class="nav-item" role="presentation">
          <a class="nav-link" id="pills-management-tab" data-toggle="pill" href="#pills-management" role="tab" aria-controls="pills-management" aria-selected="false">Management Information</a>
        </li>
        <li class="nav-item" role="presentation">
          <a class="nav-link" id="pills-financial-tab" data-toggle="pill" href="#pills-financial" role="tab" aria-controls="pills-financial" aria-selected="false">Financial Information</a>
        </li>
        <li class="nav-item" role="presentation">
          <a class="nav-link" id="pills-bank-tab" data-toggle="pill" href="#pills-bank" role="tab" aria-controls="pills-bank" aria-selected="false">Bank Information</a>
        </li>
        <li class="nav-item" role="presentation">
          <a class="nav-link" id="pills-certification-tab" data-toggle="pill" href="#pills-certification" role="tab" aria-controls="pills-certification" aria-selected="false">Certification Information</a>
        </li>
      </ul>
    </div>
    
    <div class="tab-content col-md-12 col-lg-12 col-sm-12" id="pills-tabContent">
      <div class="tab-pane fade show active" id="pills-business" role="tabpanel" aria-labelledby="pills-business-tab">
        <?php if(!empty($business)): ?>
          <div class="card">             
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">
                  <span class="card-title"><b>Company name:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($business->company_name); ?></span>
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Company date:</b></span>&nbsp;
                  <span class="card-text"><?php echo e(@substr($business->date_company,0,10)); ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Type business:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($business->type_business); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Contact name:</b></span>
                  <span class="card-text"><?php echo e($business->contact_name); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Zip code:</b></span>
                  <span class="card-text"><?php echo e($business->zip); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>President name:</b></span>
                  <span class="card-text"><?php echo e($business->president_name); ?></span>  
                </li>  
                <li class="list-group-item">
                  <span class="card-title"><b>Address:</b></span>
                  <span class="card-text"><?php echo e($business->address); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Ruc or tax:</b></span>
                  <span class="card-text"><?php echo e($business->ruc_tax); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Website:</b></span>
                  <span class="card-text"><?php echo e($business->website); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Secretary name:</b></span>
                  <span class="card-text"><?php echo e($business->secretary_name); ?></span>  
                </li>                         
                <li class="list-group-item">
                  <span class="card-title"><b>Dba:</b></span>
                  <span class="card-text"><?php echo e($business->dba); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>Cellphone number:</b></span>
                  <span class="card-text"><?php echo e($business->cell_phone); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>Country:</b></span>
                  <span class="card-text"><?php echo e($business->country); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>City:</b></span>
                  <span class="card-text"><?php echo e($business->city); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>State:</b></span>
                  <span class="card-text"><?php echo e($business->state); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>Phone:</b></span>
                  <span class="card-text"><?php echo e($business->phone); ?></span>  
                </li>     
                <li class="list-group-item">
                  <span class="card-title"><b>Client:</b></span>
                  <span class="card-text"><?php echo e($business->client_name); ?></span>  
                </li>   
                <li class="list-group-item">
                  <span class="card-title"><b>Type:</b></span>
                  <?php if($business->is_buyer == "true"): ?>
                    <span class="card-text">Buyer</span>  
                  <?php else: ?>
                    <span class="card-text">Seller</span>  
                  <?php endif; ?>
                </li>        
              </ul>
            </div>               
          </div>
        <?php else: ?> 
          <div class="alert alert-warning" role="alert">There is not information</div>
        <?php endif; ?>
      </div>
      <div class="tab-pane fade" id="pills-management" role="tabpanel" aria-labelledby="pills-management-tab">
        <?php if(!empty($management)): ?>
          <div class="card">             
            <div class="card-body">
              <?php $__currentLoopData = $management; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$mng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="list-group list-group-flush">
                  <li class="list-group-item" style="text-align: center;background-color: #ced9d9;">
                    <span class="card-title"><b>#<?php echo e($key + 1); ?></b></span>&nbsp;
                  </li>
                  <li class="list-group-item">
                    <span class="card-title"><b>Name:</b></span>&nbsp;
                    <span class="card-text"><?php echo e($mng->name); ?></span>
                  </li>
                  <li class="list-group-item">
                    <span class="card-title"><b>Id Number:</b></span>&nbsp;
                    <span class="card-text"><?php echo e($mng->idno); ?></span>  
                  </li>
                  <li class="list-group-item">
                    <span class="card-title"><b>Percentage:</b></span>&nbsp;
                    <span class="card-text"><?php echo e($mng->percentage); ?>%</span>  
                  </li>          
                  <li class="list-group-item">
                    <span class="card-title"><b>Position:</b></span>
                    <span class="card-text"><?php echo e($mng->position); ?></span>  
                  </li>          
                  <li class="list-group-item">
                    <span class="card-title"><b>Birthdate:</b></span>
                    <span class="card-text"><?php echo e($mng->birthdate); ?></span>  
                  </li>           
                </ul>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>               
          </div>
        <?php else: ?>          
          <div class="alert alert-warning" role="alert">There is not information</div>          
        <?php endif; ?>
      </div>
      <div class="tab-pane fade" id="pills-financial" role="tabpanel" aria-labelledby="pills-financial-tab">
        <?php if(!empty($financial)): ?>
          <div class="card">             
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">
                  <span class="card-title"><b>Avg monthly sales:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($financial->avg_montky_sales); ?></span>
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>In how many clients?:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($financial->ams_how_clients); ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Has applicant or any entity in which applicant is an owner / partner owe any taxes that are past due?:</b></span>&nbsp;
                  <span class="card-text"><?php if($financial->has_applicant == 'checked'): ?> Yes <?php else: ?> No <?php endif; ?></span> 
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Estimated monthly financing volume:</b></span>
                  <span class="card-text"><?php echo e($financial->estimated_montly_financing); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Number of clients to finance?:</b></span>
                  <span class="card-text"><?php echo e($financial->emf_number_clients); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>What type of documents are you looking to finance (PO- Invoice)?:</b></span>
                  <span class="card-text">
                    <?php if($financial->po_finance == 'checked' && $financial->in_finance == 'checked'): ?>
                      Both
                    <?php elseif($financial->po_finance == 'checked'): ?>
                      PO
                    <?php elseif($financial->in_finance == 'checked'): ?>
                      Invoice
                    <?php endif; ?>
                  </span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Has applicant or any entity in which applicant is an owner / partner has any lawsuits pending?:</b></span>
                  <span class="card-text"><?php if($financial->lawsuits_pending == 'checked'): ?> Yes <?php else: ?> No <?php endif; ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Have you ever factored your receivables?:</b></span>
                  <span class="card-text"><?php if($financial->receivable_finance == 'checked'): ?> Yes <?php else: ?> No <?php endif; ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>If yes, when/with whom?:</b></span>
                  <span class="card-text"><?php echo e($financial->rf_when_with_whom); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Do you have a Credit Insurance policy?:</b></span>
                  <span class="card-text"><?php if($financial->credit_insurance_policy == 'checked'): ?> Yes <?php else: ?> No <?php endif; ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>If yes, when/with whom?:</b></span>
                  <span class="card-text"><?php echo e($financial->cip_when_with_whom); ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Has applicant or any entity in which applicant is an owner / partner ever declared bankruptcy?:</b></span>
                  <span class="card-text"><?php if($financial->declared_bank_ruptcy == 'checked'): ?> Yes <?php else: ?> No <?php endif; ?></span>  
                </li>           
              </ul>
            </div>               
          </div>
        <?php else: ?>
          <div class="alert alert-warning" role="alert">There is not information</div>  
        <?php endif; ?>
      </div>
      <div class="tab-pane fade" id="pills-bank" role="tabpanel" aria-labelledby="pills-bank-tab">
        <?php if(!empty($bank)): ?>
          <div class="card">             
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">
                  <span class="card-title"><b>Bank Name:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($bank->bank_name); ?></span>
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Account Name SWIFT:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($bank->account_same_swift); ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Account Number:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($bank->account_number); ?></span> 
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>ABA/Routing:</b></span>
                  <span class="card-text"><?php echo e($bank->aba_routing); ?></span>  
                </li>          
                <li class="list-group-item">
                  <span class="card-title"><b>Bank Address:</b></span>
                  <span class="card-text"><?php echo e($bank->bank_adress); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Telephone:</b></span>
                  <span class="card-text"><?php echo e($bank->telephone); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Address:</b></span>
                  <span class="card-text"><?php echo e($bank->adress); ?></span>  
                </li> 
                <li class="list-group-item">
                  <span class="card-title"><b>Account Officer:</b></span>
                  <span class="card-text"><?php echo e($bank->account_officer); ?></span>  
                </li>                 
              </ul>
            </div>               
          </div>
        <?php else: ?>
          <div class="alert alert-warning" role="alert">There is not information</div>  
        <?php endif; ?>
      </div>
      <div class="tab-pane fade" id="pills-certification" role="tabpanel" aria-labelledby="pills-certification-tab">
        <?php if(!empty($certification)): ?>
          <div class="card">             
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">
                  <span class="card-title"><b>Signer Name:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($certification->name); ?></span>
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Title:</b></span>&nbsp;
                  <span class="card-text"><?php echo e($certification->title); ?></span>  
                </li>
                <li class="list-group-item">
                  <span class="card-title"><b>Status:</b></span>&nbsp;
                  <span class="card-text">
                  <?php if(trim($certification->approved_agreed) == 'checked'): ?>
                    Approved
                  <?php else: ?>
                    Not approved
                  <?php endif; ?>
                  </span> 
                </li>                               
              </ul>
            </div>               
          </div>
        <?php else: ?> 
          <div class="alert alert-warning" role="alert">There is not information</div> 
        <?php endif; ?>
      </div>
    </div>    

  </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/users/show.blade.php ENDPATH**/ ?>