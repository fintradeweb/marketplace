

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <?php if(isset($creditapproved) && count($creditapproved)>0): ?>    
      <div class="col-md-12 col-lg-12 col-sm-12 alert alert-success" role="alert">
        <h5 class="alert-heading">Approved Credit Information</h5>
        <hr>
        <?php $__currentLoopData = $creditapproved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p><strong><?php if($credit->type_document == 1): ?> PO <?php else: ?> Invoice <?php endif; ?>:</strong>&nbsp;
          Credit Line: <?php echo e($credit->credit_line); ?>&nbsp;/&nbsp;Advanced:<?php echo e($credit->advance); ?>&nbsp;/&nbsp;Maximum amount:<?php echo e($credit->maximun_amount); ?>&nbsp;/&nbsp;Deadline:<?php echo e($credit->deadline); ?>&nbsp;/&nbsp;Interest Rate:<?php echo e($credit->interest_rate); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				  
      </div>
    <?php else: ?> 
      <div class="col-md-12 col-lg-12 col-sm-12 alert alert-success" role="alert">
        <h5 class="alert-heading">Information</h5>
        <p>Your credit has not been approved yet!</p>
      </div>
    <?php endif; ?>
    <div class="col-md-8">
      <h5>Welcome <?php echo e($name); ?>!</h5></br>      
      <div class="list-group">
        <a href="/home" class="list-group-item list-group-item-action active">Home</a>
        <?php if(isset($creditapproved) && count($creditapproved)>0): ?>  
          <a href="/financing" class="list-group-item list-group-item-action">Request Financing</a>
        <?php endif; ?>
      </div> 
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/home.blade.php ENDPATH**/ ?>