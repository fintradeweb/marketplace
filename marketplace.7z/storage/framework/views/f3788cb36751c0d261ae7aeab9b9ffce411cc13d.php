

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-xs-12 col-sm-12 col-md-10 text-center"> 
      <h5>Notification List</h5></br>      
      <table width="100%" border="1"> 
        <thead>
          <th class="text-center">From</th>
          <th class="text-center">Date</th>
          <th class="text-center">Description</th>
        </thead> 
        <tbody>
          <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <tr>
              <td><a href="/notification/view/<?php echo e($notification->id); ?>">User</a></td>
              <td><a href="/notification/view/<?php echo e($notification->id); ?>"><?php echo e(substr($notification->created_at,0,19)); ?></a></td>
              <td> 
                <a href="/notification/view/<?php echo e($notification->id); ?>"><?php echo e($notification->description); ?></a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/notification/index.blade.php ENDPATH**/ ?>