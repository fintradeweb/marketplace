
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
 <div class="row justify-content-center">
   <div class="col-md-8 col-lg-8 col-sm-12">
     <div class="alert alert-success">
      <?php echo e(session('status')); ?>

     </div>
   </div>
 </div>    
<?php endif; ?>

  <div class="container">
    <div class="row justify-content-center">
      <div class="row col-md-12 p-4">
        <div class="col-md-6"><h5>List of Clients</h5></div>
        <div class="col-md-6 ml-auto text-right">
          <a type="button" class="btn btn-primary" href="/clients/create">New Client</a>
        </div>
      </div>
      <div class="col-md-12">
        <table class="table table-hover table-bordered">
          <thead>
            <tr>
              <th>Id</th>
              <th>Date created</th>
              <th>Name</th>
              <th>Token</th>
              <th>Email</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>        
          </thead>
          <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
              <tr>
                <td><?php echo e($client->id); ?></td>
                <td><?php echo e($client->created_at); ?></td>
                <td><?php echo e($client->name); ?></td>
                <td><?php echo e($client->token); ?></td>
                <td><?php echo e($client->email); ?></td>
                <?php if($client->active): ?>
                  <td>Active</td>
                <?php else: ?>
                  <td>Inactive</td>
                <?php endif; ?>                
                <td><a href="/clients/<?php echo e($client->id); ?>">Ver</a> / <a href="clients/<?php echo e($client->id); ?>/edit">Editar</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>        
      </div>
    </div>
  </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/clients/index.blade.php ENDPATH**/ ?>