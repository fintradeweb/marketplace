<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
  <title>MarketPlace</title>
</head>
<body>
  <p>We Sorry! Your credit has been denied.</p>
  <p>The comments are:</p>
  <p><?php echo e($observation); ?></p>
  <ul>
    <li>
      <a href="http://protomarket.fintrade-acf.com/">Enter our platform</a>
    </li>
  </ul>
</body>
</html>
<?php /**PATH C:\wamp64\www\marketplace\resources\views/marketsend/creditdenied.blade.php ENDPATH**/ ?>