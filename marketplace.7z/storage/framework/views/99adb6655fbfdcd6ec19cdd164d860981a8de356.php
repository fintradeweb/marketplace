
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row justify-content-center">  
    <div class="row col-md-12 p-4">
      <div class="col-md-6"><h5>Request Financing</h5></div>
      <div class="col-md-6 ml-auto text-right">
        <a href="/"class="btn btn-primary">Return</a>
      </div>
    </div> 

    <div class="col-xs-12 col-sm-12 col-md-12">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
          <form action="" method="POST" id="frm_creditapproved">                                        
            <?php echo csrf_field(); ?>       
            <div class="col-xs-12 col-sm-12 col-md-12 text-center"> 
              <table width="100%" border="1">
                <thead>
                  <th>Type Document</th>
                  <th>File</th>
                  <th>Amount</th>
                  <th>Select</th>
                </thead>
              </table>                               
            </div>
            <br>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
              <button type="reset" class="btn btn-secondary" id="btnreset">Reset</button>
              <button type="submit" class="btn btn-primary" id="btn_save">Save</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/financing/index.blade.php ENDPATH**/ ?>