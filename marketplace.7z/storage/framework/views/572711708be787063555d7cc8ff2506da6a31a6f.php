
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-8 col-sm-12">
      <div class="alert alert-danger" role="alert">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="container">
  <div class="row justify-content-center">
    <div class="row col-md-12 p-4 text-center">
      <div class="col-md-12"><h5>Certification, Authorization</h5></div>
    </div>
    <div class="col-md-12 p-4 text-justify">  
      <form action="<?php echo e(route('certification.update',$indiv->id)); ?>" method="POST" id="frm_createownership">
        <input type="hidden" name="token" id="token" value="<?php echo e($token); ?>">
        <input type="hidden" name="email" id="email" value="<?php echo e($email); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
          <p class="text-justify">The applicant certifies that the statement made on this application and the other information provided with this application is true and complete. American Capital Financial Group is authorized to do any necessary credit or background check and to make all inquiries it deems necessary to verify accuracy and determine the Applicant’s creditworthiness.
          </p>
        </div>  
        <center><iframe width="90%" height="400" src="<?php echo e(asset('master.pdf')); ?>" frameborder="0"></iframe></center>
        <br>
        <div class="col-xs-12 col-sm-12 col-md-12">
          <div class="form-group text-center">
            <div class="form-check-inline">
            <label class="form-check-label"> 
              <strong>Approved and Agreed : <span class="text-danger">(*)</span></strong>
            </label>
            <input type="checkbox" name="approved_agreed" id="approved_agreed" class="form-check-input chk_lg" <?php echo e($indiv->approved_agreed); ?>>
            <?php $__errorArgs = ['approved_agreed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
              </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-1 col-md-1"></div>
          <div class="col-xs-12 col-sm-5 col-md-5">
            <div class="form-group">
              <strong>Name: <span class="text-danger">(*)</span></strong>
              <input type="text" name="name" id="name" class="form-control" value="<?php echo e($indiv->name); ?>" placeholder="Name">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col-xs-12 col-sm-5 col-md-5">
            <div class="form-group">
              <strong>Title: <span class="text-danger">(*)</span></strong>
              <input type="text" name="title" id="title" class="form-control" value="<?php echo e($indiv->title); ?>" placeholder="Title">
              <?php $__errorArgs = ['has_applicant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="col-xs-12 col-sm-1 col-md-1"></div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
          <button type="submit" class="btn btn-primary" id="btn_save">Save & Next</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('js/financial.js')); ?>" defer=""></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\marketplace\resources\views/certification/edit.blade.php ENDPATH**/ ?>