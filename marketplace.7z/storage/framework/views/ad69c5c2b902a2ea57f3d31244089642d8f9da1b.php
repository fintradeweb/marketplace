<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
  <title>MarketPlace</title>
</head>
<body>
  <p>Congratulations! Your credit has been approved.</p>
  <p>The approved values are:</p>
  <p>PO</p>
  <ul>
    <li>PO Credit Line: <?php echo e($creditpo->credit_line); ?></li>
    <li>PO Advance: <?php echo e($creditpo->advance); ?></li>
    <li>PO Maximum amount: <?php echo e($creditpo->maximum_amount); ?></li>
    <li>PO Deadline: <?php echo e($creditpo->deadline); ?></li>
    <li>PO Interest Rate: <?php echo e($creditpo->interest_rate); ?></li>
  </ul>
  <p>Invoice</p>
  <ul>
    <li>Invoice Credit Line: <?php echo e($creditinvoice->credit_line); ?></li>
    <li>Invoice Advance: <?php echo e($creditinvoice->advance); ?></li>
    <li>Invoice Maximum amount: <?php echo e($creditinvoice->maximum_amount); ?></li>
    <li>Invoice Deadline: <?php echo e($creditinvoice->deadline); ?></li>
    <li>Invoice Interest Rate: <?php echo e($creditinvoice->interest_rate); ?></li>
  </ul>
  <ul>
    <li>
      <a href="http://protomarket.fintrade-acf.com/">Enter our platform</a>
    </li>
  </ul>
</body>
</html>
<?php /**PATH C:\wamp64\www\marketplace\resources\views/marketsend/creditapproved.blade.php ENDPATH**/ ?>